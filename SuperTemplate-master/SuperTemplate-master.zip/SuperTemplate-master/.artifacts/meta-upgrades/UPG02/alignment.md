# UPG02 Alignment Summary (DNA)

- Objective: Emit reasoning_dna.json capturing goals, gates, evidence
- Key citations:
  - `.cursor/ai-driven-workflow/01-client-proposal-generation.md` → QUALITY CHECKS
  - `.cursor/ai-driven-workflow/02-client-discovery-initiation.md` → QUALITY GATES
  - `.cursor/ai-driven-workflow/12-quality-audit.md` → Pre-audit automation and reporting
- Notes: Schema overlays; no protocol edits
